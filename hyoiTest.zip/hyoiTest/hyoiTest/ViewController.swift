//
//  ViewController.swift
//  hyoiTest
//
//  Created by タルタル on 2020/02/14.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController,UITextFieldDelegate {
    var successText:String  = ""
    var emails:[Email]!
  //  var keys:[String]!
    
    @IBOutlet weak var loginEmailText: UITextField!
    @IBOutlet weak var loginPasswordText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //TextFieldのdelegate通知先を設定
        loginPasswordText.delegate = self
        // タイトルをセット
        self.navigationItem.title = "ログイン"
        // フォント種をAppleGothic、サイズを10に指定
        self.navigationController?.navigationBar.titleTextAttributes
            = [NSAttributedString.Key.font: UIFont(name: "AppleGothic", size: 15)!]
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //キーボードを閉じる
        textField.resignFirstResponder()
        
        return true
    }
    
    @IBAction func loginButton(_ sender: Any) {
        let userEmail =  loginEmailText.text
        let userPassword = loginPasswordText.text
        //未入力欄確認
        if(userEmail == "" || userPassword == "" ){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }
        // データ登録
        UserDefaults.standard.set(userEmail, forKey:"userEmail")
        UserDefaults.standard.set(userPassword, forKey:"userPassword")
        //UserDefaults.standard.synchronize();
        
        // メッセージアラートなど
        let myAlert = UIAlertController(title:"Alert", message: "登録完了!!", preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default){
            action in self.dismiss(animated: true, completion:nil)
        }
        myAlert.addAction(okAction)
        self.present(myAlert, animated:true,completion:nil)
        
        //firebseに登録
        let email = UserDefaults.standard.value(forKey: "userEmail")
        let pass = UserDefaults.standard.value(forKey: "userPassword")
        Auth.auth().signIn(withEmail: email as! String, password: pass as! String,completion: {(result, error) in
            //エラー処理
            if error != nil{
                print(error!)
                return
            }
            //成功した時
            self.successText = "成功しました。"
            print("ログイン成功")
            //ログイン後画面遷移
            self.performSegue(withIdentifier: "goLoginToInfo", sender: nil)
            //初期化
            self.emails = []
            //  self.keys = []
            var emailDictionary:[String:Any] = [:]
            //emailDictionaryにセット
            emailDictionary.updateValue(userEmail, forKey: "userEmail")
            //Keyを取得して格納する。
            //  let key:String = (data as AnyObject).key
            // self.keys.append(key)
            var email = Email()
            //取得した内容をEmail型にセット
            email.setFromDictionary(_dictionary: emailDictionary)
            //Emailリストに追加
            self.emails.append(email)
        })
        
        //InfoViewControllerにemailを送信
         func prepare(for segue:UIStoryboardSegue,sender:Any?){
            if loginEmailText.text != nil{
                let infoViewController = segue.destination as! InfoViewController
                infoViewController.text1 = loginEmailText.text
            }else{return}
        }
        
    }//ボタンのラスト
    func displayMyAlertMessage(userMessage: String){
        
        let myAlert = UIAlertController(title:"Alert", message: userMessage, preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default, handler:nil)
        myAlert.addAction(okAction);
        self.present(myAlert,animated:true, completion:nil)
        
    }
    
    @IBAction func goTorokuButton(_ sender: Any) {
        print("【新規登録】ボタンが押された!")
        let userEmail =  loginEmailText.text
        let userPassword = loginPasswordText.text
        //未入力欄確認
        if(userEmail == "" || userPassword == "" ){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }else if (self.successText != "成功しました。"){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }else{
            performSegue(withIdentifier: "goShinki", sender: nil)
        }
        
    }//goTorokuボタン
}

