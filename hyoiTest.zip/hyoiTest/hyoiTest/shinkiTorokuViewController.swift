//
//  shinkiTorokuViewController.swift
//  hyoiTest
//
//  Created by タルタル on 2020/02/15.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import Firebase
class shinkiTorokuViewController: UIViewController,UITextFieldDelegate {
    var successText:String  = ""
   // var emails:[Email]!
    var nextBarButtonItem: UIBarButtonItem!     // "次へ"ボタン
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //TextFieldのdelegate通知先を設定
        passwordTextField.delegate = self
        // Do any additional setup after loading the view.
         // バーボタンアイテムの初期化
          nextBarButtonItem = UIBarButtonItem(title: "次へ", style: .done, target: self, action: #selector(nextBarButtonTapped(_:)))
        // バーボタンアイテムの追加
        self.navigationItem.rightBarButtonItems = [nextBarButtonItem]
        // タイトルをセット
        self.navigationItem.title = "新規登録"
        // フォント種をAppleGothic、サイズを10に指定
        self.navigationController?.navigationBar.titleTextAttributes
            = [NSAttributedString.Key.font: UIFont(name: "AppleGothic", size: 15)!]
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //SettingsViewControllerにemailを送信
    override func prepare(for segue:UIStoryboardSegue,sender:Any?){
        let settingsViewController = segue.destination as! SettingsViewController
        settingsViewController.email = emailTextField.text
        let infoViewController = segue.destination as! InfoViewController
        infoViewController.text1 = emailTextField.text
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //キーボードを閉じる
        textField.resignFirstResponder()
        
        return true
    }
    @IBAction func torokuButton(_ sender: Any) {
        let userEmail =  emailTextField.text
        let userPassword = passwordTextField.text
        //未入力欄確認
        if(userEmail == "" || userPassword == "" ){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }//未入力確認
        else{
        // データ登録
        UserDefaults.standard.set(userEmail, forKey:"userEmail")
        UserDefaults.standard.set(userPassword, forKey:"userPassword")
        //UserDefaults.standard.synchronize();
        
        // メッセージアラートなど
        let myAlert = UIAlertController(title:"Alert", message: "登録完了!!", preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default){
            action in self.dismiss(animated: true, completion:nil)
        }
        myAlert.addAction(okAction)
        self.present(myAlert, animated:true,completion:nil)
        
    /*    //初期化
        self.emails = []
        //emailDictionaryにセット
        var emailDictionary : [String:Any] = [:]
            emailDictionary.updateValue(userEmail!, forKey: "userEmail")
        var emailIns = Email()
        //取得した内容をEmail型にセット
        emailIns.setFromDictionary(_dictionary: emailDictionary)
        //Emailリストに追加
        self.emails.append(emailIns)
        let emailId = emails[0]
            print(emailId.userEmail)*/
            
 
        //firebseに登録
        let email = UserDefaults.standard.value(forKey: "userEmail")
        let pass = UserDefaults.standard.value(forKey: "userPassword")
        Auth.auth().createUser(withEmail: email as! String, password: pass as! String,completion: {(user, error) in
            //エラー処理
            if error != nil{
                print(error!)
                return
            }
            //成功した時
            self.successText = "成功しました。"
            print("登録成功")
        })
        }//else
    }//ボタンカッコ
    func displayMyAlertMessage(userMessage: String){
        
        let myAlert = UIAlertController(title:"Alert", message: userMessage, preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default, handler:nil)
        myAlert.addAction(okAction);
        self.present(myAlert,animated:true, completion:nil)
      
    }//displayMyAlertMessageカッコ
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    // "編集"ボタンが押された時の処理
    @objc func nextBarButtonTapped(_ sender: UIBarButtonItem) {
        print("【編集】ボタンが押された!")
        let userEmail =  emailTextField.text
        let userPassword = passwordTextField.text
        //未入力欄確認
        if(userEmail == "" || userPassword == "" ){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }else if (self.successText != "成功しました。"){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }else{
            performSegue(withIdentifier: "goSetting", sender: nil)
        }
    }//nextBarButtonTapped
    
    
}
