//
//  hyoiViewController.swift
//  hyoiTest
//
//  Created by タルタル on 2020/03/14.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit

class hyoiViewController: UIViewController {
    //バーアイテムの宣言
    var  stopBarButtonItem:UIBarButtonItem! //撮影画面へ移動
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //バーボタンアイテムの初期化
        stopBarButtonItem = UIBarButtonItem(title: "stop", style: .done, target: self, action:#selector(stopBarButtonTapped(_:)))
        //バーボタンアイテムの追加
        self.navigationItem.rightBarButtonItem = stopBarButtonItem
        ///タイトルの設置
        self.navigationItem.title = "hyoi中"
        // フォント種をAppleGothic、サイズを10に指定
        self.navigationController?.navigationBar.titleTextAttributes
            = [NSAttributedString.Key.font: UIFont(name: "AppleGothic", size: 15)!]
        
        
    }//viewDidLoadのかっこ
    
    @objc func stopBarButtonTapped(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "goLast", sender: nil)
    }//hyoiBarButtonTapped

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
