//
//  Email.swift
//  hyoiTest
//
//  Created by タルタル on 2020/02/25.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import Foundation
import UIKit
import Firebase

struct Email  {
    var userEmail:String = ""
    //Dictionaryに変換する
    var toDictionary:[String:Any]{
        return[
            "userEmail": userEmail
            
        ]
    }
    //Dictionaryから自分自身に代入する。
    mutating func setFromDictionary(_dictionary:[String:Any])
    {
        userEmail = _dictionary["userEmail"] as? String ?? ""
        
    }
}//structの後ろのカッ
