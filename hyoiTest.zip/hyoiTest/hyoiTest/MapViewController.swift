//
//  MapViewController.swift
//  hyoiTest
//
//  Created by タルタル on 2020/03/11.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
class MapViewController: UIViewController,MKMapViewDelegate {

    var mapIchi:CLLocationCoordinate2D??
    var mapName:String?
    var mapImage:UIImage?
    //バーアイテムの宣言
    var  hyoiBarButtonItem:UIBarButtonItem! //撮影画面へ移動
    override func viewDidLoad() {
        super.viewDidLoad()
        //バーボタンアイテムの初期化
        hyoiBarButtonItem = UIBarButtonItem(title: "hyoi", style: .done, target: self, action:#selector(hyoiBarButtonTapped(_:)))
        //バーボタンアイテムの追加
        self.navigationItem.rightBarButtonItem = hyoiBarButtonItem
        
        // Do any additional setup after loading the view.
        ///タイトルの設置
        self.navigationItem.title = "Map"
        // フォント種をAppleGothic、サイズを10に指定
        self.navigationController?.navigationBar.titleTextAttributes
            = [NSAttributedString.Key.font: UIFont(name: "AppleGothic", size: 15)!]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let mapInfo = mapIchi
        let mapInfo2 = mapName
        let mapInfo3 = mapImage
        ///ピンを打つ
        //MKPointAnnotationインスタンスを取得し、ピンを生成。
        let annotation = MKPointAnnotation()
        //ピンの置く場所に緯度経度を設定
        annotation.coordinate = mapInfo as! CLLocationCoordinate2D
        //ピンのタイトル設定
        annotation.title = mapInfo2
        func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
            if annotation is MKUserLocation {
                return nil
            }//mapView
            
            let reuseId = "pin"
            var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
            if pinView == nil {
                pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
                pinView?.animatesDrop = true
                //pinに画像を入れる。
                let rightImageView = UIImageView(image: mapInfo3)
                rightImageView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
                rightImageView.contentMode = .scaleAspectFit
                
                if #available(iOS 13.3, *) {
                    pinView?.detailCalloutAccessoryView = rightImageView
                } else {
                    pinView?.rightCalloutAccessoryView = rightImageView
                }
                
            }
            else {
                pinView?.annotation = annotation
            }
            
            return pinView
        }//mapView
        
        
        //ピンを地図に置く
        self.dispMap.addAnnotation(annotation)
        //半径500mの範囲を表示。
        self.dispMap.region = MKCoordinateRegion(center:mapIchi as! CLLocationCoordinate2D,latitudinalMeters:500.0, longitudinalMeters:500.0)
        
    }//viewWillAppearのかっこ
    
    //ピンにcallOutAccessoryを追加（ボタン）
    func mapView(mapView: MKMapView, didAddAnnotationViews views: [MKAnnotationView]) {
        for view in views {
            view.rightCalloutAccessoryView = UIButton(type: UIButton.ButtonType.detailDisclosure)
        }
    }//mapView
    //タップを検出
    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        debugPrint(view)
    }//mapView
    
    @IBOutlet weak var dispMap: MKMapView!
    
    @objc func hyoiBarButtonTapped(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "goHyoi", sender: nil)
    }//hyoiBarButtonTapped
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}//ViewController
