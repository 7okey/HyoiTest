//
//  Avatar.swift
//  hyoiTest
//
//  Created by タルタル on 2020/02/29.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import Foundation
import Firebase
import UIKit

struct Avatar  {
    var emailId:String = ""
    var name:String = ""
    var latitude:String = ""
    var longitude:String = ""
    var point:Int =  0
    var picture:String = ""
    var avatarId:String = ""
    var message:String = ""
    //Dictionaryに変換する
    var toDictionary:[String:Any]{
        return[
            "emailId": emailId,
            "name": name,
            "latitude":latitude,
            "longitude":longitude,
            "point":point,
            "picture":picture,
            "avatrId":avatarId,
            "message":message
            
        ]
    }
    //Dictionaryから自分自身に代入する。
    mutating func setFromDictionary(_dictionary:[String:Any])
    {
        emailId = _dictionary["emailId"] as? String ?? ""
        name = _dictionary["name"] as? String ?? ""
        latitude = _dictionary["latitude"] as? String ?? ""
        longitude = _dictionary["longitude"] as? String ?? ""
        point = _dictionary["point"] as? Int ?? 0
        picture = _dictionary["picture"] as? String ?? ""
        avatarId = _dictionary["avatarId"] as? String ?? ""
        message = _dictionary["message"] as? String ?? ""
    }
}//structの後ろのカッ
