//
//  SettingsViewController.swift
//  hyoiTest
//
//  Created by タルタル on 2020/02/20.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import Firebase
import CoreLocation
//import CryptoSwift

class SettingsViewController:UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextFieldDelegate {
    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var pictureImage: UIImageView!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var messageText: UITextField!
    @IBOutlet weak var myLocationLabel: UILabel!
    var locationManager:CLLocationManager!
    //緯度
    var latitudeNow:String = ""
    //経度
    var longitudeNow:String = ""
    var gyakuGeo : String = ""
    var successText:String = ""
    var userName:String?
    var userMessage:String?
    var pictureString:String = ""
    var email :String?
    var point:Int = 0
    var avatarId:Int = 0
    var pushCountNumber:Int = 0
//バーボタンアイテムの宣言
    var okBarButtonItem :UIBarButtonItem! //「完了」ボタン
   
    override func viewDidLoad() {
        super.viewDidLoad()
        emailLabel.text = email
       
        // Do any additional setup after loading the view.
        nameText.delegate = self
        messageText.delegate = self
        //バーボタンアイテムの初期化
        okBarButtonItem = UIBarButtonItem(title: "完了", style: .done, target: self, action: #selector(okBarButtonTapped(_:)))
        //バーボタンアイテムの追加
        self.navigationItem.rightBarButtonItem = okBarButtonItem
        //ロケーションマネージャのセットアップ
        setupLocationManager()
        
    }//viewDidLoadのかっこ
  /*  override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //ロケーションマネージャのセットアップ
        setupLocationManager()
    }*/
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //taskIdMaxのDBからの読み取り（1回目:画面遷移後）
        Database.database().reference().child("avatars").observeSingleEvent(of: .value, with:{(snapshot) in
            if let data = snapshot.value as? [String:AnyObject]{
                let avatarIdMax = data["avatarIdMax"] as? Int
                print(avatarIdMax!)
                self.avatarId = avatarIdMax! + 1
                
            }
        }, withCancel: nil)
    }//viewWillAppear
    //InfoViewControllerにemailを送信
    override func prepare(for segue:UIStoryboardSegue,sender:Any?){
        let infoViewController = segue.destination as! InfoViewController
        infoViewController.text1 = emailLabel.text
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //キーボードを閉じる
        textField.resignFirstResponder()
        if (nameText.text != nil || messageText.text != nil){
            print(nameText)
            print(messageText)
        }
        //デフォルトで行うのでtrueを返す。
        return true
    }//textFieldShouldReturn
    @IBAction func cameraButtonAction(_ sender: Any) {
        //カメラかフォトライブラリーどちらから画像を取得するか選択
        let alertController = UIAlertController(title: "確認", message: "選択してください", preferredStyle: .actionSheet)
        //カメラが利用可能かチェック
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            //カメラを起動するための選択肢を定義
            let cameraAction = UIAlertAction(title: "カメラ", style: .default, handler: {(action:UIAlertAction) in
            //カメラを起動
                let imagePickerController = UIImagePickerController()
                    imagePickerController.sourceType = .camera
                    imagePickerController.delegate = self
                    self.present(imagePickerController,animated: true, completion: nil)
       
            })
            alertController.addAction(cameraAction)
        }//ifのカッコ
        //フォトライブラリーが利用可能かをチェック
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            //フォトライブラリーを起動をするための選択肢を定義
        let photoLibraryAction = UIAlertAction(title: "フォトライブラリー", style: .default, handler: {(action:UIAlertAction) in
               //フォトライブラリーを起動
            let imagePickerController = UIImagePickerController()
            imagePickerController.sourceType = .photoLibrary
            imagePickerController.delegate = self
            self.present(imagePickerController,animated: true, completion: nil)
            })//クロジャーかっこ
            alertController.addAction(photoLibraryAction)
        }//ifのかっこ
        
        //キャンセルの選択肢を定義
        let cancelAction = UIAlertAction(title:"キャンセル",style:.cancel,handler:nil)
        alertController.addAction(cancelAction)
        //選択肢を画面に表示
        present(alertController, animated: true, completion: nil)
    }//cameraボタンカッコ
    //(1)撮影が終わった時に呼ばれるdelegateメゾット
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //(2)撮影した写真を、配置したpictureImageに渡す
        pictureImage.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
       
        
        //(3)モーダルビューを閉じる
        dismiss(animated: true, completion: nil)
        if pictureImage.image != nil{
            pictureString = Image2String(image: pictureImage.image!)!
        }else{return}
    }//imagePickerContrllerのかっこ
    //エンコード関数
    func Image2String(image:UIImage) -> String? {
        
        //画像をNSDataに変換
        let data:NSData? = image.pngData()! as NSData
        
        //NSDataへの変換が成功していたら
        if let pngData:NSData = data {
            
            //BASE64のStringに変換する
            let encodeString:String =
                pngData.base64EncodedString(options: .lineLength64Characters)
            
            return encodeString
            
        }
        
        return nil
        
    }//エンコード関数のかっこ
   
    
   
    @IBAction func getLocationInfo(_ sender: Any) {
        //マネージャの設定
        let status = CLLocationManager.authorizationStatus()
        if status == .denied{
            showAlert()
        }else if status == .authorizedWhenInUse{
            self.myLocationLabel.text = gyakuGeo//地名化した位置情報を代入/
            print("gyakuGeoは\(gyakuGeo)")
        }//elseIfのかっこ
    }//ボタンかっこ
    //ロケーションマネイジャーのセットアップ
    func setupLocationManager() {
        locationManager = CLLocationManager()
        
        // 権限をリクエスト
        guard let locationManager = locationManager else { return }
        locationManager.requestWhenInUseAuthorization()
        
        // マネージャの設定
        let status = CLLocationManager.authorizationStatus()
        
        // ステータスごとの処理
        if status == .authorizedWhenInUse {
            locationManager.delegate = self as CLLocationManagerDelegate
            locationManager.startUpdatingLocation()
           
        }
    }//setupLocationManagerのかっこ
    /// アラートを表示する
    func showAlert() {
        let alertTitle = "位置情報取得が許可されていません。"
        let alertMessage = "設定アプリの「プライバシー > 位置情報サービス」から変更してください。"
        let alert: UIAlertController = UIAlertController(
            title: alertTitle,
            message: alertMessage,
            preferredStyle:  UIAlertController.Style.alert
        )
        // OKボタン
        let defaultAction: UIAlertAction = UIAlertAction(
            title: "OK",
            style: UIAlertAction.Style.default,
            handler: nil
        )
        // UIAlertController に Action を追加
        alert.addAction(defaultAction)
        // Alertを表示
        present(alert, animated: true, completion: nil)
    }//アラートのかっこ
    
    @IBAction func sendDbButton(_ sender: Any) {
        ///名前、メッセージの取得
        if nameText.text != nil{
             userName = nameText.text!
            print(userName)
        }else{return}
        if messageText.text != nil{
             userMessage = messageText.text!
            print(userMessage)
        }else{return}
        if (latitudeNow == "" || longitudeNow == "" || pictureString == ""){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "空のフォームがあります。")
            return
        }else{
            //位置情報を暗号化
          /*  let key = "abcdefghijklmnop" // 128bit(16文字)のキーを入れる
            let iv =  "1234567890123456" // データをシフト演算するキー128bit(16文字)
            // EncryptionAESのインスタンス化
            let aes = EncryptionAES()
            //緯度経度を暗号化
            let latitudeNowEncrypted = try! aes.encrypt(key: key, iv: iv, text: latitudeNow)
            let longitudeNowEncrypted = try! aes.encrypt(key: key, iv: iv, text: longitudeNow)
            print("緯度を暗号化：\(latitudeNowEncrypted)")
            print("経度を暗号化：\(longitudeNowEncrypted)")*/
            
            //avatarIdMaxを取得する
            Database.database().reference().child("avatars").observeSingleEvent(of: .value, with:{(snapshot) in
                if let data = snapshot.value as? [String:AnyObject]{
                    let avatarIdMax = data["avatarIdMax"] as? Int
                    print("avatarIdMax:\(String(describing: avatarIdMax))")
                    self.pushCountNumber = avatarIdMax! + 1
                    print(self.pushCountNumber)
                    self.avatarId = self.pushCountNumber
                }
            }, withCancel: nil)
           ///emailアドレスを追加で登録
            let emailId = email
            print(emailId!)
            
            ///FBに保存
            let values = ["name":userName!, "message":userMessage!, "latitude":latitudeNow, "longitude":longitudeNow, "picture":pictureString, "emailId":emailId!, "point":point] as [String:Any]
            Database.database().reference().child("avatars").child("\(String(avatarId))").updateChildValues(values, withCompletionBlock: { (error, reference) in
                //エラー処理
                if error != nil{
                    print(error!)
                    return
                }
                //成功した時
                print("avatar内容の送信成功")
                self.successText = "avatar内容の送信成功"
            })
            ///FBにavatarIdMaxを保存
            let taskValues = ["avatarIdMax":avatarId] as [String:Any]
            Database.database().reference().child("avatars").updateChildValues(taskValues, withCompletionBlock: { (error, reference) in
                //エラー処理
                if error != nil{
                    print(error!)
                    return
                }
                //成功した時
                print("avatarIdMax内容の送信成功")
                
            })
        }//else
       
    }//sendDbButton
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    // "完了"ボタンが押された時の処理
    @objc func okBarButtonTapped(_ sender: UIBarButtonItem) {
       print("【完了】ボタンが押された!")
        let userName =  nameText.text
        let userHitokoto = messageText.text
        //未入力欄確認
        if(userName == "" || userHitokoto == "" ){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }else if (self.successText != "avatar内容の送信成功"){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }else{
            performSegue(withIdentifier: "goInfo", sender: nil)
        }
    }//okBarButtonTapped
    //「完了」ボタンアラート関数
    func displayMyAlertMessage(userMessage: String){
        
        let myAlert = UIAlertController(title:"Alert", message: userMessage, preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default, handler:nil)
        myAlert.addAction(okAction);
        self.present(myAlert,animated:true, completion:nil)
        
    }
}//ViewControllerのかっこ

extension SettingsViewController: CLLocationManagerDelegate {
    
    /// 位置情報が更新された際、位置情報を格納する
    /// - Parameters:
    ///   - manager: ロケーションマネージャ
    ///   - locations: 位置情報
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{ //last→firstに変える。
            let latitude = location.coordinate.latitude
            let longitude = location.coordinate.longitude
        // 位置情報を格納する
            self.latitudeNow = String(latitude)
            self.longitudeNow = String(longitude)
        
            let location = CLLocation (latitude : location.coordinate.latitude , longitude : location.coordinate.longitude )
            CLGeocoder().reverseGeocodeLocation(location) {placemarks, error in guard
                let placemark = placemarks?.first,error == nil,
                let country = placemark.country,
                let pref = placemark.administrativeArea,
                let city = placemark.locality,
                let town = placemark.thoroughfare,
                let townMore = placemark.subThoroughfare
                else{
                    self.gyakuGeo = ""
                    return
                }//else
                
                self.gyakuGeo = "\(country) \(pref) \(city) \(town) \(townMore)"
                
                
              //  print("\(pref) \(city)")
            }//CLGeocoder()のかっこ
        }//ifLet
}
}
