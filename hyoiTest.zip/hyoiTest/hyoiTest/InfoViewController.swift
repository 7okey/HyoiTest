//
//  InfoViewController.swift
//  hyoiTest
//
//  Created by タルタル on 2020/02/26.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import Firebase
import CoreLocation

class InfoViewController: UIViewController {
    @IBOutlet weak var avatarImage: UIImageView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var pointLabel: UILabel!
    var goBarButtonItem:UIBarButtonItem! //"Go!"ボタン
    var text1:String?
    var count:Int = 0
    var selectedEmailId:String?
    var selectedName:String?
    var selectedLatitude:String?
    var selectedLongitude:String?
    var selectedPicture:String?
    var selectedAvatarId:String?
    var selectedPonint:String?
    var selectedMessage:String?
    var avatars:[Avatar]!
    var keys :[String]!
    var locationManager:CLLocationManager!
    var latitudeNow:String = ""
    var longitudeNow:String = ""
    var gyakuGeo:String = ""
    var locCord2D:CLLocationCoordinate2D?
    
    override func viewDidLoad() {
        super.viewDidLoad()
       let loginId = text1
        // Do any additional setup after loading the view.
        //バーアイテムの初期化
        goBarButtonItem = UIBarButtonItem(title: "Go!", style: .done, target: self, action:#selector(goBarButtonTapped(_:)))
        //バーアイテムの追加
         self.navigationItem.rightBarButtonItem = goBarButtonItem
        // タイトルをセット
        self.navigationItem.title = "ステータス"
        // フォント種をAppleGothic、サイズを10に指定
        self.navigationController?.navigationBar.titleTextAttributes
            = [NSAttributedString.Key.font: UIFont(name: "AppleGothic", size: 15)!]
        //ロケーションマネジャのセットアップ
        setupLocationManager()
        
        //マネージャの設定
        let status = CLLocationManager.authorizationStatus()
        if status == .denied{
            showAlert()
        }else if status == .authorizedWhenInUse{
            self.locationLabel.text = gyakuGeo//地名化した位置情報を代入/
            print("gyakuGeoは\(gyakuGeo)")
        }//elseIfのかっこ
    }//viewDidLoad
    //MapViewControllerにemailを送信
    override func prepare(for segue:UIStoryboardSegue,sender:Any?){
        let mapViewController = segue.destination as! MapViewController
        let exInfoViewController = InfoViewController()
        mapViewController.mapIchi = locCord2D
        mapViewController.mapName = gyakuGeo
        mapViewController.mapImage = self.avatarImage.image!
    }
    //ロケーションマネイジャーのセットアップ
    func setupLocationManager() {
        locationManager = CLLocationManager()
        
        // 権限をリクエスト
        guard let locationManager = locationManager else { return }
        locationManager.requestWhenInUseAuthorization()
        
        // マネージャの設定
        let status = CLLocationManager.authorizationStatus()
        
        // ステータスごとの処理
        if status == .authorizedWhenInUse {
          locationManager.delegate = self as! CLLocationManagerDelegate
            locationManager.startUpdatingLocation()
            
        }
    }//setupLocationManagerのかっこ
    /// アラートを表示する
    func showAlert() {
        let alertTitle = "位置情報取得が許可されていません。"
        let alertMessage = "設定アプリの「プライバシー > 位置情報サービス」から変更してください。"
        let alert: UIAlertController = UIAlertController(
            title: alertTitle,
            message: alertMessage,
            preferredStyle:  UIAlertController.Style.alert
        )
        // OKボタン
        let defaultAction: UIAlertAction = UIAlertAction(
            title: "OK",
            style: UIAlertAction.Style.default,
            handler: nil
        )
        // UIAlertController に Action を追加
        alert.addAction(defaultAction)
        // Alertを表示
        present(alert, animated: true, completion: nil)
    }//アラートのかっこ
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let ref = Database.database().reference()
        ref.child("avatars").observe(.value){
            (snapshot) in
            //初期化
            self.avatars = []
            self.keys = []
            for data in snapshot.children{
                var fireDictionary : [String:Any] = [:]
                let snapData = data as! DataSnapshot
                if let dictionarySnapData = snapData.value as? [String:AnyObject]{
                    let emailId = dictionarySnapData["emailId"] as? String
                    let name = dictionarySnapData["name"] as? String
                    let latitude = dictionarySnapData["latitude"] as? String
                    let  longitude = dictionarySnapData["longitude"] as? String
                    let message = dictionarySnapData["message"] as? String
                    let picture = dictionarySnapData["picture"] as? String
                    let avatarId = dictionarySnapData["avatarId"] as? String
                    let point = dictionarySnapData["point"] as? Int
                    //fireDictionaryにセット
                    fireDictionary.updateValue(emailId!, forKey: "emailId")
                    fireDictionary.updateValue(name!, forKey: "name")
                    fireDictionary.updateValue(latitude!, forKey: "latitude")
                    fireDictionary.updateValue(longitude!, forKey: "longitude")
                    fireDictionary.updateValue(message!, forKey: "message")
                    fireDictionary.updateValue(picture!, forKey: "picture")
                    fireDictionary.updateValue(avatarId!, forKey: "avatarId")
                    fireDictionary.updateValue(point!, forKey: "point")
                    
                    //Keyを取得して格納する
                    let key:String = (data as AnyObject).key
                    self.keys.append(key)
                    var avatar = Avatar()
                    //取得した内容をAvatar型にセット
                    avatar.setFromDictionary(_dictionary:fireDictionary)
                    //Avatarリストに追加
                    self.avatars.append(avatar)
                    print("forの繰り返し回数：\(String(self.count))目です。")
                    let avatarNumber = self.avatars[self.count]
                    let loginEmailId = self.text1
                    if (avatarNumber.emailId == loginEmailId){
                        print("appendしました。")
                        //追加(emailId)
                        self.selectedEmailId = avatarNumber.emailId
                        //追加(name)
                        self.selectedName = avatarNumber.name
                        //追加(緯度)
                        self.selectedLatitude = avatarNumber.latitude
                        //追加(経度)
                        self.selectedLongitude = avatarNumber.longitude
                        //追加(picutre)
                        self.selectedPicture = avatarNumber.picture
                        //追加(Id)
                       self.selectedAvatarId = avatarNumber.avatarId
                        //追加(point)
                        self.selectedPonint = String(avatarNumber.point)
                        //追加(message)
                        self.selectedMessage = avatarNumber.message
                        
                    }else{
                        return
                    }//else
                    self.count = self.count + 1
                }//dictionarySnapData
            }//for
            self.nameTextField.text = self.selectedName
            self.pointLabel.text = self.selectedPonint
            if self.selectedPicture != nil{
                self.avatarImage.image = String2Image(imageString: self.selectedPicture!)
            }else{
                print("デコードを失敗しました。")
            }
        }//observe
        //StringをUIImageに変換する
        func String2Image(imageString:String) -> UIImage?{
            
            //空白を+に変換する
            var base64String = imageString.replacingOccurrences(of: "+", with:"")
            
            //BASE64の文字列をデコードしてNSDataを生成
            let decodeBase64:NSData? =
                NSData(base64Encoded:base64String, options: NSData.Base64DecodingOptions.ignoreUnknownCharacters)
            
            //NSDataの生成が成功していたら
            if let decodeSuccess = decodeBase64 {
                
                //NSDataからUIImageを生成
                let img = UIImage(data: decodeSuccess as Data)
                
                //結果を返却
                return img
            }
            
            return nil
            
        }//func String2Image
    }//viewWillAppearのかっこ
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    // "Go!"ボタンが押された時の処理
    @objc func goBarButtonTapped(_ sender: UIBarButtonItem) {
        print("【Go!】ボタンが押された!")
        ///FBに保存
        let values = ["name":selectedName!, "message":selectedMessage!, "latitude":latitudeNow, "longitude":longitudeNow, "picture":selectedPicture!, "emailId":selectedEmailId!, "point":Int(selectedPonint!)!] as [String:Any]
        Database.database().reference().child("avatars").child(selectedAvatarId!).updateChildValues(values, withCompletionBlock: { (error, reference) in
            //エラー処理
            if error != nil{
                print(error!)
                return
            }
            //成功した時
            print("avatar内容の送信成功")
           self.performSegue(withIdentifier: "goMap", sender: nil)
        })
        
       
    }//okBarButtonTapped

}//viewController

extension InfoViewController: CLLocationManagerDelegate {
    
    /// 位置情報が更新された際、位置情報を格納する
    /// - Parameters:
    ///   - manager: ロケーションマネージャ
    ///   - locations: 位置情報
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{ //last→firstに変える。
            let latitude = location.coordinate.latitude
            let longitude = location.coordinate.longitude
            // 位置情報を格納する
            self.latitudeNow = String(latitude)
            self.longitudeNow = String(longitude)
            locCord2D = location.coordinate //緯度経度がまとめて入っている。
            let location = CLLocation (latitude : location.coordinate.latitude , longitude : location.coordinate.longitude )
            CLGeocoder().reverseGeocodeLocation(location) {placemarks, error in guard
                let placemark = placemarks?.first,error == nil,
                let country = placemark.country,
                let pref = placemark.administrativeArea,
                let city = placemark.locality,
                let town = placemark.thoroughfare,
                let townMore = placemark.subThoroughfare
                else{
                    self.gyakuGeo = ""
                    return
                }//else
                
                self.gyakuGeo = "\(country) \(pref) \(city) \(town) \(townMore)"
                
                
                //  print("\(pref) \(city)")
            }//CLGeocoder()のかっこ
        }//ifLet
    }
}
